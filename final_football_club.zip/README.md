# Football Club Management Website

Modern full-stack application for managing football club operations. The project couples a responsive HTML/CSS/JS frontend with a PHP/MySQL backend that exposes CRUD and search endpoints for seven core entities.

## Features

- **Responsive UI** covering home, dashboards, and entity directory pages.
- **Three login modals** (player, coach, employee) routing to their dashboards.
- **Employee dashboard** with entity selector, CRUD modals, and integrated search/filter controls that synchronize with the backend.
- **Entity listings** (`players`, `coach`, `employee`, `matches`, `training_session`, `venue`, `clubs`) each with local live filtering plus server-side search via AJAX.
- **Reusable fetch helpers** for consistent table rendering and status feedback.
- **Secure PHP endpoints** validating table/column names against an allow-list and using prepared statements for data mutations and LIKE searches.

## Project Structure

```
football-club/
├── frontend/
│   ├── index.html
│   ├── player-dashboard.html
│   ├── coach-dashboard.html
│   ├── employee-dashboard.html
│   ├── players.html
│   ├── coaches.html
│   ├── employees.html
│   ├── matches.html
│   ├── training.html
│   ├── venues.html
│   ├── clubs.html
│   ├── styles.css
│   └── script.js
├── backend/
│   ├── db_config.php
│   ├── schema.php
│   ├── fetch_data.php
│   ├── insert_data.php
│   ├── update_data.php
│   ├── delete_data.php
│   └── search_data.php
└── README.md
```

## Prerequisites

- PHP 8+ with `mysqli` extension enabled
- MySQL 5.7+ / MariaDB 10+
- A local web server (XAMPP, WAMP, MAMP, or PHP's built-in server)

## Database Setup

1. Create the database:
   ```sql
   CREATE DATABASE IF NOT EXISTS football_club
     CHARACTER SET utf8mb4
     COLLATE utf8mb4_unicode_ci;
   ```

2. Switch to the database:
   ```sql
   USE football_club;
   ```

3. Create the tables:
   ```sql
   CREATE TABLE clubs (
     Club_ID INT PRIMARY KEY,
     Club_Name VARCHAR(100),
     City VARCHAR(50)
   );

   CREATE TABLE coach (
     Coach_ID INT PRIMARY KEY,
     Coach_Name VARCHAR(100),
     Years_of_experience INT,
     Salary DECIMAL(10,2),
     Coach_PhoneNumber VARCHAR(15),
     Club_ID INT,
     FOREIGN KEY (Club_ID) REFERENCES clubs(Club_ID)
   );

   CREATE TABLE venue (
     Venue_ID INT PRIMARY KEY,
     Venue_Name VARCHAR(100),
     Venue_Location VARCHAR(50)
   );

   CREATE TABLE training_session (
     TS_ID INT PRIMARY KEY,
     TS_Date DATE,
     TS_Time TIME,
     Duration VARCHAR(20),
     Type VARCHAR(50),
     Gear VARCHAR(50),
     Coach_ID INT,
     Venue_ID INT,
     FOREIGN KEY (Coach_ID) REFERENCES coach(Coach_ID),
     FOREIGN KEY (Venue_ID) REFERENCES venue(Venue_ID)
   );

   CREATE TABLE players (
     Player_ID INT PRIMARY KEY,
     Player_Name VARCHAR(100),
     Player_DOB DATE,
     Gender VARCHAR(10),
     Height_in_cm DECIMAL(5,2),
     Weight_in_kg DECIMAL(5,2),
     No_of_Matches INT,
     Player_PhoneNumber VARCHAR(15),
     Club_ID INT,
     FOREIGN KEY (Club_ID) REFERENCES clubs(Club_ID)
   );

   CREATE TABLE register (
     Player_ID INT,
     Club_ID INT,
     Fees DECIMAL(10,2),
     PRIMARY KEY (Player_ID, Club_ID),
     FOREIGN KEY (Player_ID) REFERENCES players(Player_ID),
     FOREIGN KEY (Club_ID) REFERENCES clubs(Club_ID)
   );

   CREATE TABLE matches (
     Match_ID INT PRIMARY KEY,
     Date DATE,
     Time TIME,
     Home_Team VARCHAR(100),
     Away_Team VARCHAR(100),
     Result VARCHAR(100),
     Venue_ID INT,
     FOREIGN KEY (Venue_ID) REFERENCES venue(Venue_ID)
   );

   CREATE TABLE play (
     Player_ID INT,
     Match_ID INT,
     PRIMARY KEY (Player_ID, Match_ID),
     FOREIGN KEY (Player_ID) REFERENCES players(Player_ID),
     FOREIGN KEY (Match_ID) REFERENCES matches(Match_ID)
   );

   CREATE TABLE attends (
     Player_ID INT,
     TS_ID INT,
     PRIMARY KEY (Player_ID, TS_ID),
     FOREIGN KEY (Player_ID) REFERENCES players(Player_ID),
     FOREIGN KEY (TS_ID) REFERENCES training_session(TS_ID)
   );

   CREATE TABLE employee (
     Emp_ID INT PRIMARY KEY,
     Emp_Name VARCHAR(100),
     Emp_Salary DECIMAL(10,2),
     Emp_Dept VARCHAR(50),
     Emp_PhoneNumber VARCHAR(15)
   );

   -- Enforce minimum player weight (60 kg) before inserts
   DELIMITER $$
   CREATE TRIGGER validate_player_weight
   BEFORE INSERT ON players
   FOR EACH ROW
   BEGIN
     IF NEW.Weight_in_kg < 60 THEN
       SIGNAL SQLSTATE '45000'
         SET MESSAGE_TEXT = 'Player is underweight. Minimum required weight is 60 kg.';
     END IF;
   END$$
   DELIMITER ;
   ```

4. Insert sample data:

   **Clubs:**
   ```sql
   INSERT INTO clubs VALUES
   (201,'SPIT Football Club','Mumbai'),
   (202,'St. Xavier\'s College','Mumbai'),
   (203,'IIT Bombay','Mumbai'),
   (204,'NMIMS','Mumbai'),
   (205,'KJ Somaiya College','Mumbai'),
   (206,'TSEC','Mumbai'),
   (207,'Ruia College','Mumbai'),
   (208,'Wilson College','Mumbai'),
   (209,'Mithibai College','Mumbai'),
   (210,'HR College','Mumbai');
   ```

   **Coach:**
   ```sql
   INSERT INTO coach VALUES
   (301,'Rajesh Menon',12,90000,'9876509876',201),
   (302,'Arjun Sharma',10,85000,'9812312345',202),
   (303,'Suresh Iyer',15,95000,'9823498765',203),
   (304,'Manoj Reddy',9,80000,'9765437890',204),
   (305,'Anil Kapoor',8,78000,'9867598765',205),
   (306,'Sanjay Joshi',14,97000,'9812345654',206),
   (307,'Ravi Deshmukh',11,88000,'9934567890',207),
   (308,'Karthik Nair',13,91000,'9867543210',208),
   (309,'Vijay Chauhan',10,84000,'9845123456',209),
   (310,'Harish Patel',7,76000,'9887654312',210);
   ```

   **Venue:**
   ```sql
   INSERT INTO venue VALUES
   (501,'Wankhede Stadium','Mumbai'),
   (502,'Brabourne Stadium','Mumbai'),
   (503,'DY Patil Stadium','Mumbai'),
   (504,'Bandra Kurla Complex Ground','Mumbai'),
   (505,'MIG Cricket Club Ground','Mumbai'),
   (506,'Bharatiya Vidya Bhavan Ground','Mumbai'),
   (507,'Khar Gymkhana Ground','Mumbai'),
   (508,'Islam Gymkhana Ground','Mumbai'),
   (509,'Parsee Gymkhana Ground','Mumbai'),
   (510,'Cross Maidan Ground','Mumbai');
   ```

   **Training Session:**
   ```sql
   INSERT INTO training_session VALUES
   (601,'2025-01-10','07:30:00','2 hrs','Fitness','Gym Kit',301,501),
   (602,'2025-01-11','08:00:00','2 hrs','Batting','Pads',302,502),
   (603,'2025-01-12','08:15:00','2 hrs','Bowling','Gloves',303,503),
   (604,'2025-01-13','07:45:00','2 hrs','Fielding','Cones',304,504),
   (605,'2025-01-14','08:00:00','2 hrs','Strategy','Whiteboard',305,505),
   (606,'2025-01-15','07:30:00','3 hrs','Strength','Weights',306,506),
   (607,'2025-01-16','08:45:00','2 hrs','Teamwork','Bibs',307,507),
   (608,'2025-01-17','07:15:00','2 hrs','Warmup','Bands',308,508),
   (609,'2025-01-18','07:30:00','3 hrs','Drills','Markers',309,509),
   (610,'2025-01-19','08:15:00','2 hrs','Endurance','Water Bottles',310,510);
   ```

   **Players:**
   ```sql
   INSERT INTO players VALUES
   (401,'Amit Singh','1998-04-15','Male',178,72,50,'9876541230',201),
   (402,'Ravi Patel','1997-07-30','Male',182,75,60,'9809875432',202),
   (403,'Karan Mehta','1999-06-22','Male',176,70,55,'9812312345',203),
   (404,'Siddharth Rao','1998-03-13','Male',180,73,48,'9823412354',204),
   (405,'Vikas Nair','1996-12-20','Male',170,71,65,'9976543210',205),
   (406,'Rahul Joshi','1995-12-14','Male',175,68,70,'9934567800',206),
   (407,'Arjun Kumar','1998-09-05','Male',179,70,58,'9944123456',207),
   (408,'Rohan Desai','1997-10-09','Male',177,69,66,'9845123678',208),
   (409,'Harish Iyer','1999-01-08','Male',181,74,40,'9876123450',209),
   (410,'Nikhil Sharma','1998-05-08','Male',179,74,52,'9956781234',210),
   (411,'Manish Verma','1999-04-14','Male',180,73,61,'9812345601',201),
   (412,'Suresh Yadav','1997-11-07','Male',178,76,54,'9823456712',201),
   (413,'Ankit Bansal','1998-07-03','Male',172,72,47,'9856780945',201),
   (414,'Ritesh Kumar','1999-02-10','Male',184,77,45,'9845678934',201),
   (415,'Deepak Soni','1998-12-17','Male',180,75,49,'9878901267',201),
   (416,'Mohit Chawla','1997-03-24','Male',177,69,53,'9890121378',201),
   (417,'Lokesh Gupta','1996-09-20','Male',176,69,44,'9890123489',201),
   (418,'Rohit Bhatia','1999-06-23','Male',179,73,41,'9890123478',201),
   (419,'Pankaj Jain','1997-09-14','Male',181,73,46,'9890123489',201),
   (420,'Ashish Reddy','2000-09-30','Male',182,74,49,'9901234590',201);
   ```

   **Register:**
   ```sql
   INSERT INTO register VALUES
   (401,201,15000),
   (402,202,16000),
   (403,203,15500),
   (404,204,17000),
   (405,205,14500),
   (406,206,16500),
   (407,207,15000),
   (408,208,17500),
   (409,209,16000),
   (410,210,15000);
   ```

   **Matches:**
   ```sql
   INSERT INTO matches VALUES
   (701,'2025-02-01','16:00:00','Mumbai Strikers','St. Xavier\'s College','Mumbai won',501),
   (702,'2025-02-02','18:00:00','IIT Bombay','NMIMS','Draw',503),
   (703,'2025-02-03','17:00:00','KJ Somaiya College','TSEC','KJ Somaiya College won',505),
   (704,'2025-02-04','19:00:00','Ruia College','Wilson College','Wilson College won',507),
   (705,'2025-02-05','18:00:00','Mithibai College','HR College','Mithibai College won',509),
   (706,'2025-02-06','18:00:00','St. Xavier\'s College','IIT Bombay','St. Xavier\'s College won',502),
   (707,'2025-02-07','19:00:00','Mumbai Strikers','TSEC','TSEC won',506),
   (708,'2025-02-08','16:30:00','Wilson College','Ruia College','Draw',508),
   (709,'2025-02-09','19:00:00','NMIMS','Mithibai College','NMIMS won',510),
   (710,'2025-02-10','17:00:00','HR College','KJ Somaiya College','KJ Somaiya College won',505);
   ```

   **Play:**
   ```sql
   INSERT INTO play VALUES
   (401,701),
   (402,702),
   (403,703),
   (404,704),
   (405,705),
   (406,706),
   (407,707),
   (408,708),
   (409,709),
   (410,710);
   ```

   **Attends:**
   ```sql
   INSERT INTO attends VALUES
   (401,601),
   (402,602),
   (403,603),
   (404,604),
   (405,605),
   (406,606),
   (407,607),
   (408,608),
   (409,609),
   (410,610);
   ```

   **Employee:**
   ```sql
   INSERT INTO employee VALUES
   (101,'Rohit Sharma',55000,'Administration','9876543210'),
   (102,'Priya Mehta',60000,'Finance','9812345678'),
   (103,'Vikram Rao',58000,'Logistics','9823412345'),
   (104,'Neha Patel',57000,'HR','9876543129'),
   (105,'Anand Kumar',53000,'Marketing','9878766655'),
   (106,'Kiran Desai',52000,'Accounts','9812345789'),
   (107,'Sunita Joshi',54000,'Operations','9798564321'),
   (108,'Rahul Verma',56000,'Support','9956789345'),
   (109,'Meena Iyer',51000,'Procurement','98876501234'),
   (110,'Deepak Singh',50000,'Security','9876543213');
   ```

## Backend Configuration

Update `backend/db_config.php` with your local credentials. Default configuration is:

```php
$host = "localhost";
$user = "root";
$password = "ruhiriya0926*";
$dbname = "football_club";
```

> ⚠️ For production or shared environments, replace hard-coded credentials with environment variables and never commit secrets.

### API Endpoints

All endpoints return JSON and expect/produce UTF-8.

| File | Method | Parameters | Description |
|------|--------|------------|-------------|
| `fetch_data.php` | GET | `table` | Fetches all rows from the requested table. |
| `search_data.php` | GET | `table`, `column`, `value` | Performs a case-insensitive `LIKE` search on a column. |
| `insert_data.php` | POST (JSON) | `table`, `data` | Inserts a new record. Only whitelisted columns are accepted. |
| `update_data.php` | POST (JSON) | `table`, `data` | Updates fields on an existing row. Requires the table's primary key. |
| `delete_data.php` | POST (JSON) | `table`, `data` | Deletes a row. Requires the primary key field. |

Example payload for insert/update/delete:

```json
{
  "table": "players",
  "data": {
    "Player_ID": 421,
    "Player_Name": "Alex Fernandes",
    "Player_DOB": "1998-05-15",
    "Gender": "Male",
    "Height_in_cm": 175.50,
    "Weight_in_kg": 70.00,
    "No_of_Matches": 45,
    "Player_PhoneNumber": "9876543210",
    "Club_ID": 201
  }
}
```

## Running the App

1. Serve the project directory through a local web server so PHP endpoints are accessible (e.g. move `football-club` into your web root or run `php -S localhost:8000` inside the project).
2. Ensure the MySQL database is running and tables exist.
3. Access `frontend/index.html` through your web server (`http://localhost/football-club/frontend/index.html`). The frontend expects the backend at `../backend` relative to the HTML files.
4. Use the Employee dashboard for CRUD tasks; other dashboards are read-only views tailored to players and coaches.

## Customisation

- **Schema adjustments:** Edit `backend/schema.php` to add/remove columns and propagate changes through database definitions and frontend forms.
- **Table columns & forms:** Modify `tableSchemas` in `frontend/script.js` to control labels, field types, and filters.
- **Styling:** Update `frontend/styles.css` for branding tweaks.

## Troubleshooting

- If tables do not populate, open the browser console to inspect fetch errors. Ensure PHP scripts are reachable and CORS is not an issue when hosting separately.
- Verify your PHP environment has the `mysqli` extension enabled; otherwise, the backend will fail to connect.
- CRUD operations return descriptive JSON messages. Surface these to users or log them for debugging as needed.

---

Enjoy managing your football club with a unified dashboard experience!

